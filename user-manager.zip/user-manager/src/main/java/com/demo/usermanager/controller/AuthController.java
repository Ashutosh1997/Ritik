package com.demo.usermanager.controller;

import com.demo.usermanager.model.Error;
import com.demo.usermanager.repository.UserRepository;
import com.demo.usermanager.repository.entity.User;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.Optional;

@Controller
@AllArgsConstructor
public class AuthController {

    private final UserRepository userRepository;

    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        model.addAttribute("user", new User());
        return "register";
    }

    @PostMapping("/register")
    public String registerUser(@ModelAttribute("user") User user, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "register";
        }

        userRepository.save(user.toBuilder().isActive(false).role("USER").password(user.getPassword()).build());
        return "redirect:/login";
    }

    @GetMapping("/login")
    public String showLoginForm(Model model) {
        model.addAttribute("user", new User());
        return "login";
    }

    @GetMapping("/logout")
    public String logout(Model model) {
        model.addAttribute("user", new User());
        return "login";
    }

    @PostMapping("/login")
    public String login(@ModelAttribute("user") User user, Model model) {
        Optional<User> foundDetails = userRepository.findByUsernameAndPassword(user.getUsername(), user.getPassword());

        if (foundDetails.isPresent()) {
            User found = foundDetails.get();
            if (found.getRole().equals("USER")) {
                return "redirect:/users/welcome-user";
            } else {
                return "redirect:/users/all";
            }
        } else {
            model.addAttribute("error", Error.builder().message("Invalid credentials.").build());
            return "login";
        }
    }
}
