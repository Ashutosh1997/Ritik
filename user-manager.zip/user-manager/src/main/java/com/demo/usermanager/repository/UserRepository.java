package com.demo.usermanager.repository;

import com.demo.usermanager.repository.entity.User;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface UserRepository extends MongoRepository<User, String> {
    boolean existsByUsername(String username);

    boolean existsByEmailId(String username);

    User findByUsername(String username);

    Optional<User> findByUsernameAndPassword(String username, String password);
}